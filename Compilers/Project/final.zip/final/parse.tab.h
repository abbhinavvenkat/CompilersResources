/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSE_TAB_H_INCLUDED
# define YY_YY_PARSE_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    BOOLEAN = 258,
    CALLOUT = 259,
    CLASS = 260,
    FALSE = 261,
    TRUE = 262,
    INT = 263,
    ID = 264,
    INT_LITERAL = 265,
    HEXA_LITERAL = 266,
    CHAR = 267,
    ASSIGN_OP = 268,
    STR_LITERAL = 269,
    CHAR_LITERAL = 270,
    VOID_DECL = 271,
    CURLY_OPEN = 272,
    CURLY_CLOSE = 273,
    SQUARE_OPEN = 274,
    SQUARE_CLOSE = 275,
    CIRCLE_OPEN = 276,
    CIRCLE_CLOSE = 277,
    COLON = 278,
    COMMA = 279,
    EQ_OP = 280,
    COND_OP = 281,
    LOWERARITH_OP = 282,
    HIGHERARITH_OP = 283,
    REL_OP = 284,
    NOT_OP = 285
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 23 "./parse.y" /* yacc.c:1909  */

	int ival;
	float fval;
	char *sval;
	bool bval;

#line 92 "parse.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_PARSE_TAB_H_INCLUDED  */
