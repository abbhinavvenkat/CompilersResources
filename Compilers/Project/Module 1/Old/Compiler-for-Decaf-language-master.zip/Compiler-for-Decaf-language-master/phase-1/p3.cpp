// statement : if 
// statement : for
// statement : return 
class Program{
    int x,y[100];
    
    boolean func(int a, int b){
    
        int a1,a2;
        boolean b1,b2;
        
        if(b1 == true){
            return (1+2);
        }
        else
        {
            y[11] += 10;
            return;
        }

    }
}
