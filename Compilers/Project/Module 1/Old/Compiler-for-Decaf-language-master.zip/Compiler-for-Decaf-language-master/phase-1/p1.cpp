// variable and method declaration
class Program{
    int x,y[100];
    boolean z,t[20];
    boolean func1(int a, int b){
        int z;
    }
    int func2(int c, boolean d){
        int t;
    }
}
