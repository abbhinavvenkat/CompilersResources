// statement : block
// statement : method_call
// statement : continue break

class Program{
    int x,y[100];
    
    boolean func(int a, int b){
    
        int a1,a2;
        {
            func(!2,-3);
            continue;
            {
                break;
            }
        }
    }
}
