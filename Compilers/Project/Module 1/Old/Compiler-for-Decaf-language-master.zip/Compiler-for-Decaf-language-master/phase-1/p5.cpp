// statement : for
// expr : ( expr )
// expr : expr binary_op method_call
class Program{
    int x,y[100];
    
    boolean func(int a, int b){
		for i=0, 99{
			if(a[i]==5)
			{
                p = (10 && func(true, false));
			}
		}
    }
}
