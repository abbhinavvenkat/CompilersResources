// Random
class Program{
    int x,y[100];
   
    int sum(int x){
        return x>=1;
    }

    boolean func(int a, int b){
        y[10] += sum(88);
        return;
    }
}
