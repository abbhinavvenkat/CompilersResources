// statement : location ASSIGNMENT expr
class Program{
    int x,y[100];
    
    boolean func(int a, int b){
    
        int a1,a2;
        boolean b1,b2;
        
        b1=false;
        a1 -= 20;
        y[10] += 1;
    }
}
