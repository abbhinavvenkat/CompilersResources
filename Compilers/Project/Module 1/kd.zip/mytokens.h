#define BOOLEAN 1
#define CALLOUT 2
#define CLASS 3
#define FALSE 4
#define TRUE 5
#define INT 6
#define ID 7
#define INT_LITERAL 8
#define CHAR_LITERAL 9 // Call later
#define STR_LITERAL 10 // Called in function
#define VOID_DECL 11
#define STRING_SEP 12
#define CHAR 21
#define STRING 22
#define COLON 23
#define CHAR_SEP 24
#define ARITH_OP 25
#define REL_OP 26
#define ASSIGN_OP 27
#define EQ_OP 28
#define COND_OP 29
